#include<iostream>
#include<string.h>
#include<conio.h>
#include<fstream>
#include<stdio.h>
#include<conio.h>
#include<dos.h>
#include<windows.h>
#define clrscr() system("cls");

using namespace std;


//Function Declaration

void file();
void front();
void password();
int mainstart();
void Delay(int x=2);


void setcolor(int ForgC) //function to change setcolor
 {
	WORD wColor;
	HANDLE hStdOut = GetStdHandle(STD_OUTPUT_HANDLE);
	CONSOLE_SCREEN_BUFFER_INFO csbi;
	if(GetConsoleScreenBufferInfo(hStdOut, &csbi))
 	{
  		wColor = (csbi.wAttributes & 0xF0) + (ForgC & 0x0F);
		SetConsoleTextAttribute(hStdOut, wColor);
	}
	return;
}


class PassStore //To Store The Password
{
	public:
		int Fileswitch;
		char password[10];
}ob8;






void password()   /*Password*/
{
	fstream t1;
	ob8.Fileswitch=5;
	t1.open("classrecord/doc1.dat",ios::in);
	t1.seekg(0);
	while(t1.read((char*)&ob8,sizeof(ob8)))
	{}
	t1.close();
	char password[10],ch,temp[10],temp2[10]={"close"};
	strcpy(temp,ob8.password);
	int i;
	start:

	printf("\nTo Open And Run the program Entre the password: \n");
	char dumm[]={"************"};
	int j;
	for(i=0;i <5;i++)
	{
		ch = getch();
		password[i] = ch;
		cout<<dumm[i];
		int a =	ch;
		if(a==8)
		{
			cout<<"\b\b  \b\b";
			if(0<i)
				i=i-2;
			else if(0==i)
				i=i-1;
		}
	}

	if((temp[0]==password[0])&&(temp[1]==password[1])&&(temp[2]==password[2])&&(temp[3]==password[3])&&(temp[4]==password[4]))
	{
		cout<<"\nPROGRAM IS OPENED....";
	}
	else if ((temp2[0]==password[0])&&(temp2[1]==password[1])&&(temp2[2]==password[2])&&(temp2[3]==password[3])&&(temp2[4]==password[4]))
	{
		exit(5);
	}
	else
	{
		clrscr();
		{
			cout<<"\nPassword is WRONG try again or type ( close ) to close";
			goto start;
		}
	}
}



//File Function to Creat File in Folder
void file()
{
	fstream t1;
	ob8.Fileswitch=5;
	t1.open("classrecord/doc1.dat",ios::in);
	t1.seekg(0);
	while(t1.read((char*)&ob8,sizeof(ob8)))
	{

	}
	t1.close();
	if(ob8.Fileswitch==5)
	{
        mkdir("classrecord");			//Directary Creat
    
		 //File creations
	    ofstream fstu("classrecord/doc3.dat"),fhregrn("classrecord/doc2.dat"),filetest("classrecord/doc1.dat"),bb("classrecord/doc4.dat");
		
		t1.open("classrecord/doc1.dat",ios::in|ios::out|ios::ate);
		ob8.Fileswitch=1;
		char fscreen[200]="\n\t This is The First Time You Opening The Program\n\n\t\tTo Secure Your Data Enter A Five Digit Password :";
		int l=strlen(fscreen);
		for(int i=0;i<l;i++)
		{
			cout<<fscreen[i];
			Delay(5);
		}
		fgets(ob8.password,6,stdin);
		strcpy(fscreen,"\n\t\tYour Password is...: ");
		l=strlen(fscreen);
		for(int i=0;i<l;i++)
		{
			cout<<fscreen[i];
			Delay(5);
		}
		cout<<ob8.password;
		strcpy(fscreen," \n\t\tNext Time You Will  Need This Password To Open The Program");
		l=strlen(fscreen);
		for(int i=0;i<l;i++)
		{
			cout<<fscreen[i];
			Delay(5);
		}
		getch();
		t1.write((char*)&ob8,sizeof(ob8));
		t1.close();	
	}

}
void front()      /*Front page display*/
{
	clrscr();
	char temp[2000]="\t############################################################\n\n\t\t\t    WELCOME TO PROGRAM\n\n\t############################################################\n\n\t\t\t \"FREE CLASS\" Finder\n\t\t\t Created Date: 2018-11-06\n\n\n\n\n\n\n\n\n\n\nSUBMITED TO:\t\t\t\t\t\tSUBMITED BY:\n     Code For Acet Hackathon\t\t\t\t   1.ABDHESH NAYAK\n\t\t\t\t\t\t\t   UNV.Roll:1701448\n\t\t\t\t\t\t\t   2.Uday Kumar Sah(1701469)\n\t\t\t\t\t\t\t   B.Tech IT 3rd Sem\n\n";
	int l=strlen(temp);
	for(int i=0;i<l;i++)
	{
		cout<<temp[i];
		Delay();
	}
}

void Delay(int x)
{ int m=0,s=0,ms=0,mms=0,h=0;
while(h<2)
{
	mms++;

	if(mms==5){
		mms=0;
		ms++;
	if(ms==59){
		ms=0;
		s++;
		if(s==59){
			s=0;
			m++;
			if(m==59){
				m=0;
				h++;
			}
		}
	}
	}
}
}


