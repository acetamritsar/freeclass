

#include"help.cpp"

class room //Class to store all the rooms
{
	public:
	int ptr;
	room()
	{
		ptr=0;
	}
	char roomn[25][20];
	int rn;	
	int roomalocate() //Function to allocate the rooms
	{
		cout<<"Inilize all the room"<<endl;
		cout<<"Enter the No of room in department:";
		cin>>rn;
		cout<<"Enter the Number alocated to all the name in the department respectively:\n";
		for(int i=0;i<rn;i++)
		{
			cout<<"Enter the Room Number "<<i+1<<": ";
			cin>>roomn[i];
		}
		ptr=1;
		room:show();
	}
	show()		//Function to show the allocated roooms
	{
		cout<<"\nAlocated Room List :";
		for(int i=0;i<rn;i++)
		{
			cout<<"\t"<<roomn[i];
		}
	}		

}ob1;

class routine //Class to store all the Routines of sections
{
	public:
		char rooms[35][20]; //It store rooms of all the lecture....if there is class in 202 romm no. int routine 202 will be a element of rooms variable
		int routinenum;
		int classroutine()
		{
			char temp2[20];
			int j,temp,ptr=0;
			int lecture=7,day=5;
			string daylist[5]={"Monday","Tuesday","Wednesday","Thursday","Friday"};	//Just for show the user
			cout<<"Enter the room number acording to the routine of class and Enter 0 for free lecture"<<endl;
			for(int i=0;i<lecture*day;i++)
			{
				temp=(i+1)%7;
				start:
				cout<<"Enter The routine of "<<daylist[i/7]<<" Lecture No."<<(temp==0?7:temp)<<endl;
				cin>>temp2;
				ptr=0;
				for(j=0;j<ob1.rn;j++)
				{
					if(((strcmp(temp2,ob1.roomn[j]))==0)||(strcmp(temp2,"0")==0))
					{
						ptr=1;
					}
				}	
				if(ptr!=1)
				{
					cout<<"Wrong Room Number Entered Try Again :"<<endl;
					goto start;
				}
				strcpy(rooms[i],temp2);
			}
			routine:show();
		}
		void show()	//For show the routines stored in class
		{
			int i,j,k,lecture=7,day=5;
			string daylist[5]={"Monday","Tuesday","Wednesday","Thursday","Friday"};
			cout<<"Lec.N\t";
			for(i=0;i<5;i++)
			{
				cout<<daylist[i]<<"\t\t";
			}
			cout<<endl;
			j=0;k=0;
			cout<<k+1<<"\t";
			k++;
			for(i=0;i<50;i=i+7)
			{ 
				if((i>28+j)&&(k<7))
				{
					cout<<endl;
					cout<<k+1<<"\t";
					k++;
				}
				if(i>=35+j){j++;i=j;}
				if(j>6){break;}
					cout<<rooms[i]<<"\t\t";	
			}
		}
}ob2[50];
class check	//To check the free classes
{
	public:
		int rn;
		char lecture[35][10];	//to store the avilable lecture
		int checkempty(int y,int i)	//function to check availity of class
		{
			char temp2[10];
			int j,temp,ptr=0;
			int lectur=7,day=5,routinenumber=y;
			string daylist[5]={"Monday","Tuesday","Wednesday","Thursday","Friday"};	
			for(int m=0;m<35;m++)
			{
				strcpy(temp2,"0");
				for(int l=0;l<routinenumber;l++)
				{
						if(strcmp(ob1.roomn[i],ob2[l].rooms[m])==0)
						{
							strcpy(temp2,"1");
							break;
						}	
				}
				strcpy(lecture[m],temp2);
			}
		}
		void show()	//show the available free rooms
		{
			int i,j,k,lectur=7,day=5;
			string daylist[5]={"Monday","Tuesday","Wednesday","Thursday","Friday"};
			cout<<"\nLec.N\t";
			for(i=0;i<5;i++)
			{
				cout<<daylist[i]<<"\t\t";
			}
			cout<<endl;
			j=0;k=0;
			cout<<k+1<<"\t";
			k++;
			for(i=0;i<50;i=i+7)
			{ 
				if((i>28+j)&&(k<7))
				{
					cout<<endl;
					cout<<k+1<<"\t";
					k++;
				}
				if(i>=35+j){j++;i=j;}
				if(j>6){break;}
				cout<<lecture[i]<<"\t\t";	
			}
		}
		
}ob3[50];
int admin()		//for admin use
{
	int routinenum,choice;
	fstream t1;
	do{
		setcolor(4);
		cout<<"\nSelect A Operation:\n\t1.Initialize All Rooms\n\t2.Show Alocated Room\n\t3.Initialize All The Routine\n\t4.Display All Routines\n\t5.Goto Main Menu\n\t\tEnter Your Choice: ";
		cin>>choice;	
		switch(choice)
		{
			case 1:
			{
				setcolor(7);
				ofstream t1;
				t1.open("classrecord/doc2.dat");
				t1.seekp(0);
				ob1.roomalocate();
				t1.write((char*)&ob1,sizeof(ob1));
				t1.close();
			}	break;
			case 2:
			{	
				setcolor(2);
				ifstream t2;
				t1.open("classrecord/doc2.dat");
				while(t1.read((char*)&ob1,sizeof(ob1)))
				{
					ob1.show();
				}
				t2.close();
			}	break;
			case 3:
			{
				setcolor(3);
				ifstream t2;
				ofstream t1;
				t2.open("classrecord/doc2.dat");
				while(t2.read((char*)&ob1,sizeof(ob1)));
				t2.close();
				t1.open("classrecord/doc3.dat");
				t1.seekp(0);		
				cout<<"Enter the Number of Routines";
				cin>>routinenum;
				ob2[0].routinenum=routinenum;
				for(int i=0;i<routinenum;i++)
				{
					cout<<"\n\n\tRoutine :"<<i+1<<endl<<endl;	
					ob2[i].classroutine();
				}
				t1.write((char*)&ob2,sizeof(ob2));
				t1.close();
				for(int i=0;i<ob1.rn;i++)
				{		
					ob3[i].checkempty(routinenum,i);
				}
				t1.open("classrecord/doc4.dat");
				t1.write((char*)&ob3,sizeof(ob3));
				t1.close();
			}break;
			case 4:
			{	
				setcolor(3);
				ifstream t2;
				routinenum=5;
				t2.open("classrecord/doc3.dat");
				t2.read((char*)&ob2,sizeof(ob2));
				routinenum=ob2[0].routinenum;
				for(int i=0;i<routinenum;i++)
				{
					cout<<"\n\n\tRoutine :"<<i+1<<endl<<endl;	
					ob2[i].show();
				}
			}break;
			case 5:
			{
				clrscr();
				return 0;
			}
			default:
			{
				cout<<"\n### WRONG CHOICE TRY AGAIN ###\n\n";
			}
		}
	}while(choice!=5);
}
int calculate(int day,int lect)	//To calculate all the free classes after reading the file stored in classrecoard file
{
	ifstream t3;
	t3.open("classrecord/doc2.dat");
	while(t3.read((char*)&ob1,sizeof(ob1)))
	{	}
	t3.close();
	int x,ptr;
	ifstream t2;
	t2.open("classrecord/doc4.dat");
	t2.read((char*)&ob3,sizeof(ob3));
	char temp[5];
	strcpy(temp,"0");
	x=((day-1)*7)+((lect-1));
	setcolor(10);
	cout<<"\n\tFree Classes :";
	ptr=0;
	for(int i=0;i<ob1.rn;i++)
	{	}
	for(int i=0;i<ob1.rn;i++)
	{
		if(strcmp(temp,ob3[i].lecture[x])==0)
		{
			cout<<ob1.roomn[i]<<"\t";
			ptr++;
		}
	}
	if(ptr==0)
	{
		cout<<"No Free Class Available";;
	}
			
}
int user()		//function for teachers and studenst use
{
	int day,lect;
	start:
	cout<<"\nTo See Current Free Lectures Select a working day\n\t1.Monday\n\t2.Tuesday\n\t3.Wednesday\n\t4.Thursday\n\t5.Friday\n\t\tEnter Current Day :";
	cin>>day;
	if(day<1||day>5)
	{
		cout<<"Wrong Day Selected Try again:\n\n";
		goto start;
	}
	cout<<"\nEnter The current Lecture Period 1-7 :";
	cin>>lect;
	if(lect<1||lect>7)
	{
		cout<<"Wrong Day Selected Try again:\n\n";
		goto start;
	}
	setcolor(3);
	calculate(day,lect);
	getch();
}
int main()
{
	file();	//to create files abn initialize password  if there is not preasent
	setcolor(1);	
	front();	//for intro of program
	setcolor(2);
	getch();
	clrscr();
	setcolor(3);
	mainstart();	//for start main part of the program
}
int mainstart()	//The main part of the program
{
	int choice;
	do{
		clrscr();
		setcolor(11);
		cout<<"\n\nEnter The Mode In Wich You Want To Open The Program:\n\t1.User Mode\n\t2.Admin Mode\n\t3.Exit\n\t\tEnter Your Choice :";
		cin>>choice;
		switch(choice)
		{
			case 1:
				setcolor(4);
				user();
			break;
			case 2:
				setcolor(5);
				password();
				setcolor(6);
				admin();
			break;
			case 3:
				return 0;
			break;
			default:
			{
				cout<<"\n### WRONG CHOICE TRY AGAIN ###\n\n";
			}
		}
	}while(choice!=3);
}

